// Retail UPC Finder - Product Pages
// Walmart, Target, Best Buy, Costco, Home Depot, and Lowe's.
//
// Handles SPA navigation without requiring a manual refresh.

(function () {

    console.log(
        "RETAIL UPC PRODUCT SCRIPT START:",
        location.href
    );


    /*
     * -----------------------------------------
     * PRODUCT CONTROLLER
     * -----------------------------------------
     */

    if (window.retailUPCProductController) {

        console.log(
            "RETAIL UPC PRODUCT SCRIPT ALREADY RUNNING"
        );

        return;
    }


    window.retailUPCProductController = true;


    /*
     * -----------------------------------------
     * RETAIL UPC MODULE
     * -----------------------------------------
     *
     * Do not assume upc.js has already executed.
     */

    function getRetailUPC() {

        return window.RetailUPC || null;
    }


    async function waitForRetailUPC(
        attempts = 20,
        delay = 100
    ) {

        for (
            let i = 0;
            i < attempts;
            i++
        ) {

            if (
                window.RetailUPC
            ) {

                return window.RetailUPC;
            }


            await new Promise(
                resolve =>
                    setTimeout(
                        resolve,
                        delay
                    )
            );
        }


        console.error(
            "RetailUPC module never became available"
        );


        return null;
    }


    /*
     * -----------------------------------------
     * PRODUCT PAGE CHECK
     * -----------------------------------------
     */

    function isProductPage() {

        const host =
            location.hostname.toLowerCase();


        const path =
            location.pathname;


        if (host.includes("target"))
            return /\/p\//.test(path);


        if (host.includes("walmart"))
            return /\/ip\/[^/?#]+\/\d+/.test(path);


        if (host.includes("bestbuy"))
            return /\/product\/.*\/sku\/\d+/i.test(path);


       if (host.includes("costco"))
    return (
        /\/[^/?#]+\.product\.\d+\.html/i.test(path) ||
        /\/p\/-\/[^/?#]+\/\d+/i.test(path)
    );


        if (host.includes("homedepot"))
            return /\/(?:p|pep)\/[^/?#]+\/\d+/.test(path);


        if (host.includes("lowes"))
            return /\/pd\/[^/?#]+\/\d+/.test(path);


        return false;
    }


    /*
     * -----------------------------------------
     * NEXT_DATA
     * -----------------------------------------
     */

    function getNextData() {

        const script =
            document.getElementById(
                "__NEXT_DATA__"
            );


        if (!script)
            return null;


        try {

            return JSON.parse(
                script.textContent
            );

        } catch (e) {

            console.log(
                "NEXT_DATA parse failed:",
                e
            );

            return null;
        }
    }


    /*
     * -----------------------------------------
     * WALMART
     * -----------------------------------------
     */

    function extractWalmartUPC() {

        const RetailUPC =
            getRetailUPC();


        if (!RetailUPC) {

            console.log(
                "Walmart extraction waiting for RetailUPC"
            );

            return null;
        }


        const data =
            getNextData();


        if (data) {

            const upc =
                RetailUPC.extractWalmart(
                    document
                );


            if (upc)
                return upc;
        }


        /*
         * Visible UPC fallback.
         */

        const candidates =
            document.querySelectorAll(
                "div, tr, li, span"
            );


        for (
            const el of candidates
        ) {

            const text =
                el.textContent.trim();


            if (
                text.length < 80 &&
                /^UPC[:\s]/i.test(text)
            ) {

                const match =
                    text.match(
                        /UPC[:\s]+([0-9]{8,14})/i
                    );


                if (match) {

                    const digits =
                        match[1]
                            .replace(
                                /\D/g,
                                ""
                            );


                    if (
                        digits.length === 12 &&
                        RetailUPC.isValidUPC(
                            digits
                        )
                    ) {

                        return digits;
                    }
                }
            }
        }


        return null;
    }


    /*
     * -----------------------------------------
     * BEST BUY
     * -----------------------------------------
     */

    function extractBestBuyUPC() {

        const RetailUPC =
            getRetailUPC();


        if (!RetailUPC)
            return null;


        console.log(
            "BEST BUY UPC EXTRACTION START"
        );


        /*
         * Search scripts.
         */

        const scripts =
            document.querySelectorAll(
                "script"
            );


        for (
            const script of scripts
        ) {

            const text =
                script.textContent;


            if (
                !text ||
                text.length < 12
            ) {

                continue;
            }


            const limited =
                text.length > 500000
                    ? text.substring(
                        0,
                        500000
                    )
                    : text;


            const upc =
                RetailUPC.findBestBuyUPC(
                    limited
                );


            if (upc)
                return upc;
        }


        /*
         * Body fallback.
         */

        const body =
            document.body;


        if (!body)
            return null;


        const text =
            body.textContent || "";


        const limitedText =
            text.length > 500000
                ? text.substring(
                    0,
                    500000
                )
                : text;


        const upc =
            RetailUPC.findBestBuyUPC(
                limitedText
            );


        if (upc) {

            console.log(
                "BEST BUY UPC FOUND FROM BODY:",
                upc
            );


            return upc;
        }


        return null;
    }


    /*
     * -----------------------------------------
     * TARGET
     * -----------------------------------------
     */

    function extractTargetUPC() {

        const RetailUPC =
            getRetailUPC();


        if (!RetailUPC)
            return null;


        console.log(
            "TARGET PRODUCT EXTRACTION START"
        );


        const upc =
            RetailUPC.extractTarget(
                document,
                location.href
            );


        console.log(
            "TARGET PRODUCT UPC:",
            upc
        );


        return upc;
    }


    /*
     * -----------------------------------------
     * COSTCO
     * -----------------------------------------
     */

    function extractCostcoUPC() {

        const RetailUPC =
            getRetailUPC();


        if (!RetailUPC)
            return null;


        console.log(
            "COSTCO PRODUCT EXTRACTION START"
        );


        const upc =
            RetailUPC.extract(
                "costco",
                document,
                location.href
            );


        console.log(
            "COSTCO PRODUCT UPC:",
            upc
        );


        return upc;
    }


    /*
     * -----------------------------------------
     * HOME DEPOT
     * -----------------------------------------
     */

    function extractHomeDepotUPC() {

        const RetailUPC =
            getRetailUPC();


        if (!RetailUPC)
            return null;


        console.log(
            "HOME DEPOT PRODUCT EXTRACTION START"
        );


        const upc =
            RetailUPC.extract(
                "homedepot",
                document,
                location.href
            );


        console.log(
            "HOME DEPOT PRODUCT UPC:",
            upc
        );


        return upc;
    }


    /*
     * -----------------------------------------
     * LOWE'S
     * -----------------------------------------
     */

    function extractLowesUPC() {

        const RetailUPC =
            getRetailUPC();


        if (!RetailUPC)
            return null;


        console.log(
            "LOWES PRODUCT EXTRACTION START"
        );


        const upc =
            RetailUPC.extract(
                "lowes",
                document,
                location.href
            );


        console.log(
            "LOWES PRODUCT UPC:",
            upc
        );


        return upc;
    }


    /*
     * -----------------------------------------
     * LIVE EXTRACTION
     * -----------------------------------------
     */

    function extractUPC() {

        const host =
            location.hostname.toLowerCase();


        if (host.includes("walmart"))
            return extractWalmartUPC();


        if (host.includes("target"))
            return extractTargetUPC();


        if (host.includes("bestbuy"))
            return extractBestBuyUPC();


        if (host.includes("costco"))
            return extractCostcoUPC();


        if (host.includes("homedepot"))
            return extractHomeDepotUPC();


        if (host.includes("lowes"))
            return extractLowesUPC();


        return null;
    }


    /*
     * -----------------------------------------
     * FETCH FALLBACK
     * -----------------------------------------
     */

    const fetchedProductUPC =
        new Map();


    async function fetchProductUPC(url) {

        if (!url)
            return null;


        if (
            fetchedProductUPC.has(url)
        ) {

            return fetchedProductUPC.get(url);
        }


        console.log(
            "PRODUCT FETCH FALLBACK:",
            url
        );


        try {

            const response =
                await fetch(
                    url,
                    {
                        credentials: "include",

                        headers: {
                            "accept":
                                "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",

                            "cache-control":
                                "no-cache"
                        }
                    }
                );


            console.log(
                "PRODUCT FALLBACK STATUS:",
                response.status,
                response.url
            );


            if (!response.ok) {

                fetchedProductUPC.set(
                    url,
                    null
                );


                return null;
            }


            const html =
                await response.text();


            console.log(
                "PRODUCT FALLBACK HTML LENGTH:",
                html.length
            );


            const RetailUPC =
                await waitForRetailUPC();


            if (!RetailUPC) {

                fetchedProductUPC.set(
                    url,
                    null
                );


                return null;
            }


            const host =
                location.hostname.toLowerCase();


            /*
             * BEST BUY
             */

            if (
                host.includes("bestbuy")
            ) {

                const upc =
                    RetailUPC.findBestBuyUPC(
                        html
                    );


                console.log(
                    "PRODUCT FALLBACK BEST BUY UPC:",
                    upc
                );


                fetchedProductUPC.set(
                    url,
                    upc || null
                );


                return upc || null;
            }


            /*
             * Parse HTML.
             */

            const doc =
                new DOMParser()
                    .parseFromString(
                        html,
                        "text/html"
                    );


            let site =
                RetailUPC.getSite(
                    host
                );


            if (!site) {

                fetchedProductUPC.set(
                    url,
                    null
                );


                return null;
            }


            let upc = null;


            if (
                site === "target"
            ) {

                upc =
                    RetailUPC.extractTarget(
                        doc,
                        response.url
                    );

            } else {

                upc =
                    RetailUPC.extract(
                        site,
                        doc,
                        response.url
                    );
            }


            console.log(
                "PRODUCT FALLBACK UPC:",
                upc,
                "SITE:",
                site
            );


            fetchedProductUPC.set(
                url,
                upc || null
            );


            return upc || null;


        } catch (e) {

            console.error(
                "PRODUCT FALLBACK FETCH FAILED:",
                e
            );


            fetchedProductUPC.set(
                url,
                null
            );


            return null;
        }
    }


    /*
     * -----------------------------------------
     * AMAZON BADGE
     * -----------------------------------------
     */

    function insertBadge(upc) {

        if (!upc)
            return false;


        const existing =
            document.getElementById(
                "retail-upc-badge"
            );


        if (existing)
            return true;


        const titleEl =
            document.querySelector(
                "h1"
            );


        if (!titleEl) {

            console.log(
                "PRODUCT BADGE: no h1 yet"
            );


            return false;
        }


        const amazonUrl =
            "https://www.amazon.com/s?k=" +
            encodeURIComponent(upc) +
            "&tag=retailupcfind-20";


        const container =
            document.createElement(
                "div"
            );


        container.id =
            "retail-upc-badge";


        container.className =
            "retail-upc-badge";


        const label =
            document.createElement(
                "span"
            );


        label.className =
            "retail-upc-label";


        label.textContent =
            "UPC: ";


        const value =
            document.createElement(
                "span"
            );


        value.className =
            "retail-upc-value";


        value.textContent =
            upc;


        const link =
            document.createElement(
                "a"
            );


        link.className =
            "retail-upc-link";


        link.href =
            amazonUrl;


        link.target =
            "_blank";


        link.rel =
            "noopener noreferrer";


        link.textContent =
            " Search on Amazon →";


        container.appendChild(
            label
        );


        container.appendChild(
            value
        );


        container.appendChild(
            link
        );


        titleEl.insertAdjacentElement(
            "afterend",
            container
        );


        console.log(
            "PRODUCT AMAZON LINK ADDED:",
            upc
        );


        return true;
    }


    /*
     * -----------------------------------------
     * REMOVE BADGE
     * -----------------------------------------
     */

    function removeBadge() {

        const badge =
            document.getElementById(
                "retail-upc-badge"
            );


        if (badge)
            badge.remove();
    }


    /*
     * -----------------------------------------
     * STATE
     * -----------------------------------------
     */

    let lastUrl =
        location.href;


    let runTimer =
        null;


    let retryTimer =
        null;


    let retryCount =
        0;


    const MAX_RETRIES =
        10;


    let runInProgress =
        false;


    /*
     * -----------------------------------------
     * RESET
     * -----------------------------------------
     */

    function resetProductState() {

        retryCount = 0;


        clearTimeout(
            runTimer
        );


        clearTimeout(
            retryTimer
        );


        runTimer = null;
        retryTimer = null;


        removeBadge();
    }


    /*
     * -----------------------------------------
     * RUN
     * -----------------------------------------
     */

    async function run() {

        if (runInProgress)
            return false;


        if (!isProductPage()) {

            removeBadge();

            return false;
        }


        const currentUrl =
            location.href;


        const existing =
            document.getElementById(
                "retail-upc-badge"
            );


        if (existing) {

            if (
                existing.dataset.productUrl ===
                currentUrl
            ) {

                return true;
            }


            existing.remove();
        }


        runInProgress =
            true;


        console.log(
            "PRODUCT RUN:",
            currentUrl
        );


        let upc = null;


        try {

            /*
             * Make sure the module exists
             * before extraction begins.
             */

            const RetailUPC =
                await waitForRetailUPC();


            if (!RetailUPC) {

                runInProgress =
                    false;


                return false;
            }


            /*
             * LIVE PAGE
             */

            upc =
                extractUPC();


            /*
             * FETCH FALLBACK
             */

            if (!upc) {

                console.log(
                    "LIVE EXTRACTION FAILED - USING FETCH FALLBACK"
                );


                upc =
                    await fetchProductUPC(
                        currentUrl
                    );
            }


        } catch (e) {

            console.error(
                "PRODUCT UPC EXTRACTION ERROR:",
                e
            );
        }


        runInProgress =
            false;


        console.log(
            "PRODUCT EXTRACT RESULT:",
            upc,
            currentUrl
        );


        if (!upc)
            return false;


        /*
         * URL could have changed while
         * fetch was running.
         */

        if (
            location.href !== currentUrl
        ) {

            console.log(
                "PRODUCT URL CHANGED DURING EXTRACTION"
            );


            return false;
        }


        const inserted =
            insertBadge(
                upc
            );


        if (!inserted)
            return false;


        const newBadge =
            document.getElementById(
                "retail-upc-badge"
            );


        if (newBadge) {

            newBadge.dataset.productUrl =
                currentUrl;


            newBadge.dataset.upc =
                upc;
        }


        retryCount = 0;


        return true;
    }


    /*
     * -----------------------------------------
     * SCHEDULE RUN
     * -----------------------------------------
     */

    function scheduleRun(delay) {

        clearTimeout(
            runTimer
        );


        runTimer =
            setTimeout(
                async function () {

                    runTimer = null;


                    if (
                        location.href !== lastUrl
                    ) {

                        return;
                    }


                    if (!isProductPage()) {

                        removeBadge();

                        return;
                    }


                    const success =
                        await run();


                    if (success) {

                        retryCount = 0;

                        return;
                    }


                    if (
                        retryCount <
                        MAX_RETRIES
                    ) {

                        retryCount++;


                        const retryDelay =
                            Math.min(
                                500 +
                                retryCount * 250,
                                2500
                            );


                        clearTimeout(
                            retryTimer
                        );


                        retryTimer =
                            setTimeout(
                                function () {

                                    retryTimer =
                                        null;


                                    scheduleRun(
                                        0
                                    );

                                },
                                retryDelay
                            );
                    }

                },
                delay
            );
    }


    /*
     * -----------------------------------------
     * URL CHANGE
     * -----------------------------------------
     */

    function checkUrl() {

        const currentUrl =
            location.href;


        if (
            currentUrl === lastUrl
        ) {

            return false;
        }


        console.log(
            "PRODUCT URL CHANGED:",
            currentUrl
        );


        lastUrl =
            currentUrl;


        resetProductState();


        if (
            isProductPage()
        ) {

            scheduleRun(
                300
            );

        } else {

            console.log(
                "NEW URL IS NOT A PRODUCT PAGE"
            );
        }


        return true;
    }


    /*
     * -----------------------------------------
     * INITIAL RUN
     * -----------------------------------------
     */

    if (
        isProductPage()
    ) {

        run().then(
            function (success) {

                if (!success) {

                    scheduleRun(
                        500
                    );
                }
            }
        );

    } else {

        console.log(
            "INITIAL URL IS NOT A PRODUCT PAGE:",
            location.href
        );
    }


    /*
     * -----------------------------------------
     * DEBOUNCED MUTATION OBSERVER
     * -----------------------------------------
     */

    let mutationTimer =
        null;


    function scheduleMutationCheck() {

        clearTimeout(
            mutationTimer
        );


        mutationTimer =
            setTimeout(
                function () {

                    mutationTimer =
                        null;


                    if (
                        checkUrl()
                    ) {

                        return;
                    }


                    if (
                        isProductPage() &&
                        !document.getElementById(
                            "retail-upc-badge"
                        )
                    ) {

                        scheduleRun(
                            250
                        );
                    }

                },
                250
            );
    }


    if (document.body) {

        const observer =
            new MutationObserver(
                function () {

                    scheduleMutationCheck();

                }
            );


        observer.observe(
            document.body,
            {
                childList: true,
                subtree: true
            }
        );
    }


    /*
     * -----------------------------------------
     * PERIODIC URL CHECK
     * -----------------------------------------
     */

    setInterval(
        function () {

            checkUrl();

        },
        500
    );


    /*
     * -----------------------------------------
     * POPSTATE
     * -----------------------------------------
     */

    window.addEventListener(
        "popstate",
        function () {

            console.log(
                "PRODUCT POPSTATE:",
                location.href
            );


            lastUrl =
                location.href;


            resetProductState();


            if (
                isProductPage()
            ) {

                scheduleRun(
                    300
                );
            }
        }
    );


    /*
     * -----------------------------------------
     * BEST BUY EXTRA RETRY
     * -----------------------------------------
     */

    if (
        location.hostname
            .toLowerCase()
            .includes("bestbuy")
    ) {

        let bestBuyTimer =
            null;


        function scheduleBestBuyRun(
            delay
        ) {

            clearTimeout(
                bestBuyTimer
            );


            bestBuyTimer =
                setTimeout(
                    function () {

                        bestBuyTimer =
                            null;


                        if (
                            location.href !==
                            lastUrl
                        ) {

                            checkUrl();

                            return;
                        }


                        if (
                            !isProductPage()
                        ) {

                            return;
                        }


                        if (
                            document.getElementById(
                                "retail-upc-badge"
                            )
                        ) {

                            return;
                        }


                        scheduleRun(
                            0
                        );


                        if (
                            retryCount <
                            MAX_RETRIES
                        ) {

                            scheduleBestBuyRun(
                                1200
                            );
                        }

                    },
                    delay
                );
        }


        scheduleBestBuyRun(
            1000
        );
    }


    console.log(
        "RETAIL UPC PRODUCT SCRIPT READY"
    );

})();