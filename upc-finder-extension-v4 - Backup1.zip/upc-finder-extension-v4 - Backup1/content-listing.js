// Retail UPC Finder - Listing Pages
// Walmart, Target, Best Buy, Costco, Home Depot, and Lowe's.
//
// Best Buy stores URLs, not DOM tile references.
// Walmart re-finds virtualized tiles after UPC extraction.

(function () {

    /*
     * -----------------------------------------
     * PREVENT DUPLICATE LOAD
     * -----------------------------------------
     */

    if (window.retailUPCListingLoaded) {

        console.log(
            "RETAIL UPC LISTING SCRIPT ALREADY RUNNING"
        );

        return;
    }

    window.retailUPCListingLoaded = true;


    const AMAZON_TAG =
        "retailupcfind-20";


    /*
     * -----------------------------------------
     * SITE
     * -----------------------------------------
     */

    function getSite() {

        const host =
            location.hostname.toLowerCase();

        if (host.includes("walmart"))
            return "walmart";

        if (host.includes("target"))
            return "target";

        if (host.includes("bestbuy"))
            return "bestbuy";

        if (host.includes("costco"))
            return "costco";

        if (host.includes("homedepot"))
            return "homedepot";

        if (host.includes("lowes"))
            return "lowes";

        return null;
    }


    const SITE =
        getSite();


    if (!SITE)
        return;


    /*
     * -----------------------------------------
     * CONFIG
     * -----------------------------------------
     */

    const CONFIG = {

        walmart: {
            links:
                'a[href*="/ip/"]',

            title:
                '[data-automation-id="product-title"]'
        },

        target: {
            links:
                'a[href*="/p/"]',

            title:
                '[data-test="product-title"]'
        },

        bestbuy: {
            links:
                'a[href*="/product/"]',

            title:
                '.product-title'
        },

        costco: {
            links:
                'a[href*=".product."]',

            title:
                '[data-testid^="Text_ProductTile_"][data-testid$="_title"]'
        },

        homedepot: {
            links:
                'a[href*="/p/"], a[href*="/pep/"]',

            title:
                'a[href*="/p/"], a[href*="/pep/"]'
        },

        lowes: {
            links:
                'a[href*="/pd/"]',

            title:
                '[data-selector="splp-prd-ttl"]'
        }

    };


    /*
     * -----------------------------------------
     * CONCURRENCY
     * -----------------------------------------
     *
     * Walmart can handle several fetches.
     * Best Buy is deliberately kept low because
     * its product pages are large.
     */

    const SCAN_CONCURRENCY =
        SITE === "walmart"
            ? 3
            : SITE === "bestbuy"
                ? 1
                : 2;


    /*
     * -----------------------------------------
     * QUEUE / CACHE
     * -----------------------------------------
     */

    const queuedURLs =
        new Set();

    const queue =
        [];

    let active =
        0;

    const cache =
        new Map();

    const MAX_CACHE =
        200;


    function setCache(
        url,
        value
    ) {

        if (
            cache.size >=
            MAX_CACHE
        ) {

            const first =
                cache.keys().next().value;

            if (first)
                cache.delete(first);
        }

        cache.set(
            url,
            value
        );
    }


    /*
     * -----------------------------------------
     * RESOLVE HREF
     * -----------------------------------------
     */

    function resolveHref(a) {

        try {

            if (!a)
                return null;


            let url =
                new URL(
                    a.href,
                    location.origin
                );


            /*
             * Walmart sponsored tracking links
             */

            if (
                SITE === "walmart" &&
                url.pathname.includes("/sp/track")
            ) {

                const rd =
                    url.searchParams.get("rd");

                if (rd) {

                    url =
                        new URL(
                            rd,
                            location.origin
                        );
                }
            }


            /*
             * Walmart URL normalization.
             */

            if (
                SITE === "walmart"
            ) {

                const match =
                    url.pathname.match(
                        /\/ip\/[^/]+\/(\d+)/i
                    );

                if (match) {

                    const productId =
                        match[1];

                    const name =
                        url.pathname
                            .split("/ip/")[1]
                            .split("/")[0];

                    return (
                        location.origin +
                        "/ip/" +
                        name +
                        "/" +
                        productId
                    );
                }
            }


            return url.href;

        } catch (e) {

            return null;
        }
    }


    /*
     * -----------------------------------------
     * PRODUCT URL
     * -----------------------------------------
     */

    function isProductURL(url) {

        if (!url)
            return false;


        if (SITE === "walmart") {

            return /\/ip\/[^/?#]+\/\d+/i.test(
                url
            );
        }


        if (SITE === "target") {

            return /\/p\/[^?#]+/i.test(
                url
            );
        }


        if (SITE === "bestbuy") {

            return /\/product\/.*\/sku\/\d+/i.test(
                url
            );
        }


        if (SITE === "costco") {

            return /\/[^/?#]+\.product\.\d+\.html/i.test(
                url
            );
        }


        if (SITE === "homedepot") {

            return /\/(?:p|pep)\/[^/?#]+\/\d+/i.test(
                url
            );
        }


        if (SITE === "lowes") {

            return /\/pd\/[^/?#]+\/\d+/i.test(
                url
            );
        }


        return false;
    }


    /*
     * -----------------------------------------
     * WAIT FOR RetailUPC
     * -----------------------------------------
     */

    async function getRetailUPC() {

        for (
            let attempt = 0;
            attempt < 30;
            attempt++
        ) {

            if (
                window.RetailUPC
            ) {

                return window.RetailUPC;
            }


            await new Promise(
                resolve =>
                    setTimeout(
                        resolve,
                        250
                    )
            );
        }


        console.error(
            "RetailUPC module is not loaded"
        );


        return null;
    }


    /*
     * -----------------------------------------
     * BEST BUY URLS
     * -----------------------------------------
     */

    function getBestBuyURLs() {

        const found =
            new Set();


        const links =
            document.querySelectorAll(
                'a[href*="/product/"]'
            );


        for (
            const a of links
        ) {

            const href =
                resolveHref(a);


            if (
                !href ||
                !/\/product\/.*\/sku\/\d+/i.test(
                    href
                )
            ) {

                continue;
            }


            found.add(
                href
            );
        }


        return Array.from(
            found
        );
    }


    /*
     * -----------------------------------------
     * FIND BEST BUY TILE
     * -----------------------------------------
     */

    function findBestBuyTile(url) {

        const match =
            String(url).match(
                /\/product\/.*\/sku\/(\d+)/i
            );


        if (!match)
            return null;


        const wantedSKU =
            match[1];


        const links =
            document.querySelectorAll(
                'a[href*="/product/"]'
            );


        for (
            const a of links
        ) {

            const href =
                resolveHref(a);


            if (!href)
                continue;


            const currentMatch =
                String(href).match(
                    /\/product\/.*\/sku\/(\d+)/i
                );


            if (
                !currentMatch ||
                currentMatch[1] !== wantedSKU
            ) {

                continue;
            }


            /*
             * Best Buy tile selectors.
             */

            let tile =
                a.closest(
                    ".sku-block"
                );


            if (!tile) {

                tile =
                    a.closest(
                        '[data-testid*="product"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        '[class*="sku-block"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        "li"
                    );
            }


            if (!tile) {

                tile =
                    a.parentElement;
            }


            if (tile)
                return tile;
        }


        return null;
    }


    /*
     * -----------------------------------------
     * FIND WALMART TILE
     * -----------------------------------------
     */

    function findWalmartTile(url) {

        if (!url)
            return null;


        const wanted =
            String(url).match(
                /\/ip\/[^/?#]+\/(\d+)/i
            );


        if (!wanted)
            return null;


        const wantedID =
            wanted[1];


        const links =
            document.querySelectorAll(
                'a[href*="/ip/"], a[href*="/sp/track"]'
            );


        for (
            const a of links
        ) {

            const href =
                resolveHref(a);


            if (!href)
                continue;


            const match =
                String(href).match(
                    /\/ip\/[^/?#]+\/(\d+)/i
                );


            if (
                !match ||
                match[1] !== wantedID
            ) {

                continue;
            }


            let tile =
                null;


            tile =
                a.closest(
                    '[data-test-id="gpt-main"]'
                );


            if (!tile) {

                tile =
                    a.closest(
                        '[data-testid="product-tile"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        '[data-automation-id="product"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        '[data-automation-id="product-tile"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        '[data-testid*="product"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        '[role="group"]'
                    );
            }


            if (!tile) {

                tile =
                    a.closest(
                        "li"
                    );
            }


            if (tile)
                return tile;
        }


        return null;
    }


    /*
     * -----------------------------------------
     * GET TILES
     * -----------------------------------------
     */

    function getTiles() {

        /*
         * BEST BUY
         */

        if (
            SITE === "bestbuy"
        ) {

            return getBestBuyURLs()
                .map(
                    url => [
                        url,
                        null
                    ]
                );
        }


        /*
         * TARGET
         */

        if (
            SITE === "target"
        ) {

            const found =
                new Map();


            const links =
                document.querySelectorAll(
                    'a[href*="/p/"]'
                );


            links.forEach(
                a => {

                    const href =
                        resolveHref(a);


                    if (
                        !href ||
                        !/\/p\/[^?#]+/i.test(
                            href
                        )
                    ) {

                        return;
                    }


                    const tile =
                        a.closest(
                            '[data-test="@web/site-top-of-funnel/ProductCardWrapper"]'
                        )
                        ||
                        a.closest(
                            '[data-test="@web/ProductCard/ProductCardVariantDefaultWrapper"]'
                        )
                        ||
                        a.closest(
                            '[data-test="@web/ProductCard/ProductCardVariantDefault"]'
                        );


                    if (!tile)
                        return;


                    if (
                        !found.has(href)
                    ) {

                        found.set(
                            href,
                            tile
                        );
                    }

                }
            );


            return Array.from(
                found.entries()
            );
        }


        /*
         * WALMART
         */

        if (
            SITE === "walmart"
        ) {

            const found =
                new Map();


            const links =
                document.querySelectorAll(
                    'a[href*="/ip/"], a[href*="/sp/track"]'
                );


            links.forEach(
                a => {

                    const href =
                        resolveHref(a);


                    if (
                        !href ||
                        !isProductURL(href)
                    ) {

                        return;
                    }


                    const tile =
                        findWalmartTile(
                            href
                        );


                    if (!tile)
                        return;


                    if (
                        !found.has(href)
                    ) {

                        found.set(
                            href,
                            tile
                        );
                    }

                }
            );


            return Array.from(
                found.entries()
            );
        }


        /*
         * COSTCO
         */

        if (
            SITE === "costco"
        ) {

            /*
             * Never process Costco product pages
             * from the listing script.
             */

            if (
                isProductURL(
                    location.href
                )
            ) {

                return [];
            }


            const found =
                new Map();


            const links =
                document.querySelectorAll(
                    'a[href*=".product."]'
                );


            links.forEach(
                a => {

                    const href =
                        resolveHref(a);


                    if (
                        !href ||
                        !isProductURL(href)
                    ) {

                        return;
                    }


                    const tile =
                        a.closest(
                            '[data-testid^="ProductTile_"]'
                        )
                        ||
                        a.closest(
                            '[data-testid*="ProductTile"]'
                        )
                        ||
                        a.closest(
                            '[class*="ProductTile"]'
                        );


                    if (!tile)
                        return;


                    if (
                        !found.has(href)
                    ) {

                        found.set(
                            href,
                            tile
                        );
                    }

                }
            );


            return Array.from(
                found.entries()
            );
        }


        /*
         * HOME DEPOT
         */

        if (
            SITE === "homedepot"
        ) {

            const found =
                new Map();


            const links =
                document.querySelectorAll(
                    'a[href*="/p/"], a[href*="/pep/"]'
                );


            links.forEach(
                a => {

                    const href =
                        resolveHref(a);


                    if (
                        !href ||
                        !isProductURL(href)
                    ) {

                        return;
                    }


                    const tile =
                        a.closest(
                            '[data-testid="product-pod"]'
                        )
                        ||
                        a.closest(
                            '[data-testid*="product-pod"]'
                        )
                        ||
                        a.closest(
                            '[class*="product-pod"]'
                        )
                        ||
                        a.closest(
                            '[class*="ProductPod"]'
                        )
                        ||
                        a.closest(
                            '[data-testid*="product"]'
                        )
                        ||
                        a.closest(
                            "li"
                        );


                    if (!tile)
                        return;


                    if (
                        !found.has(href)
                    ) {

                        found.set(
                            href,
                            tile
                        );
                    }

                }
            );


            return Array.from(
                found.entries()
            );
        }


        /*
         * LOWE'S
         */

       /*
 * -----------------------------------------
 * LOWE'S
 * -----------------------------------------
 */

if (SITE === "lowes") {

    const found =
        new Map();

    const links =
        document.querySelectorAll(
            'a[href*="/pd/"]'
        );

    links.forEach(
        a => {

            const href =
                resolveHref(a);

            if (
                !href ||
                !isProductURL(href)
            ) {
                return;
            }

            const tile =
                a.closest(
                    '[data-selector="prd-description-zone"]'
                )
                ||
                a.closest(
                    '[data-selector*="prd-"]'
                )
                ||
                a.closest(
                    '[data-testid*="product"]'
                )
                ||
                a.closest(
                    "li"
                );

            if (!tile)
                return;

            if (
                !found.has(href)
            ) {
                found.set(
                    href,
                    tile
                );
            }
        }
    );

    return Array.from(
        found.entries()
    );
}

return [];
}


      


    /*
     * -----------------------------------------
     * FETCH UPC
     * -----------------------------------------
     */

    async function fetchUPC(url) {

        /*
         * Only use cached POSITIVE results.
         *
         * A null result is NOT cached because
         * the extraction may succeed on retry.
         */

        if (
            cache.has(url)
        ) {

            const cached =
                cache.get(url);

            if (cached)
                return cached;
        }


        console.log(
            "UPC FETCH:",
            url
        );


        const RetailUPC =
            await getRetailUPC();


        if (!RetailUPC)
            return null;


        try {

            const response =
                await fetch(
                    url,
                    {
                        credentials: "include",

                        headers: {
                            "accept":
                                "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",

                            "cache-control":
                                "no-cache"
                        }
                    }
                );


            console.log(
                "UPC FETCH STATUS:",
                response.status,
                response.url
            );


            if (
                !response.ok
            ) {

                console.warn(
                    "UPC FETCH HTTP ERROR:",
                    response.status,
                    url
                );

                return null;
            }


            const html =
                await response.text();


            console.log(
                "UPC FETCH HTML LENGTH:",
                html.length
            );


            /*
             * BEST BUY
             */

            if (
                SITE === "bestbuy"
            ) {

                if (
                    typeof RetailUPC.findBestBuyUPC !==
                    "function"
                ) {

                    console.error(
                        "RetailUPC.findBestBuyUPC is missing"
                    );

                    return null;
                }


                const result =
                    RetailUPC.findBestBuyUPC(
                        html
                    );


                console.log(
                    "BEST BUY UPC RESULT:",
                    result,
                    url
                );


                if (result) {

                    setCache(
                        url,
                        result
                    );
                }


                return result || null;
            }


            /*
             * Parse HTML.
             */

            const doc =
                new DOMParser()
                    .parseFromString(
                        html,
                        "text/html"
                    );


            /*
             * Extract.
             */

            let result =
                null;


            if (
                typeof RetailUPC.extract ===
                "function"
            ) {

                result =
                    RetailUPC.extract(
                        SITE,
                        doc,
                        response.url
                    );
            }


            /*
             * Walmart NEXT_DATA fallback.
             */

            if (
                !result &&
                SITE === "walmart" &&
                typeof RetailUPC.extractWalmart ===
                "function"
            ) {

                result =
                    RetailUPC.extractWalmart(
                        doc
                    );
            }


            console.log(
                "UPC FETCH RESULT:",
                result,
                "SITE:",
                SITE
            );


            if (result) {

                setCache(
                    url,
                    result
                );
            }


            return result || null;


        } catch (e) {

            console.error(
                "UPC FETCH FAILED:",
                url,
                e
            );


            return null;
        }
    }


    /*
     * -----------------------------------------
     * ADD AMAZON LINK
     * -----------------------------------------
     */

    function addAmazonLink(
        tile,
        upc
    ) {

        if (
            !tile ||
            !upc
        ) {

            return false;
        }


        if (
            tile.querySelector(
                ".retail-upc-mini"
            )
        ) {

            return true;
        }


        const link =
            document.createElement(
                "a"
            );


        link.className =
            "retail-upc-mini";


        link.target =
            "_blank";


        link.rel =
            "noopener noreferrer";


        link.href =
            "https://www.amazon.com/s?k=" +
            encodeURIComponent(upc) +
            "&tag=" +
            AMAZON_TAG;


        link.textContent =
            "UPC " +
            upc +
            " →";


        /*
         * HOME DEPOT
         */

        if (
            SITE === "homedepot"
        ) {

            const header =
                tile.querySelector(
                    '[data-testid="product-header"]'
                );


            if (header) {

                header.appendChild(
                    link
                );

            } else {

                tile.appendChild(
                    link
                );
            }


            link.style.position =
                "relative";

            link.style.zIndex =
                "20";

            link.style.pointerEvents =
                "auto";


            return true;
        }


        /*
         * TARGET
         */

        if (
            SITE === "target"
        ) {

            const card =
                tile.closest(
                    '[data-test="@web/site-top-of-funnel/ProductCardWrapper"]'
                )
                ||
                tile.closest(
                    '[data-test="@web/ProductCard/ProductCardVariantDefaultWrapper"]'
                )
                ||
                tile.closest(
                    '[data-test="@web/ProductCard/ProductCardVariantDefault"]'
                )
                ||
                tile;


            const details =
                card.querySelector(
                    '[data-test="product-details"]'
                );


            if (details) {

                details.appendChild(
                    link
                );

            } else {

                card.appendChild(
                    link
                );
            }


            return true;
        }


        /*
         * BEST BUY
         */

        if (
            SITE === "bestbuy"
        ) {

            const title =
                tile.querySelector(
                    'a[href*="/product/"]'
                );


            if (title) {

                title.after(
                    link
                );

            } else {

                tile.appendChild(
                    link
                );
            }


            return true;
        }


        /*
         * WALMART
         */

        if (
            SITE === "walmart"
        ) {

            const title =
                tile.querySelector(
                    CONFIG[SITE].title
                )
                ||
                tile.querySelector(
                    '[data-automation-id="product-title"]'
                );


            if (title) {

                title.insertAdjacentElement(
                    "afterend",
                    link
                );

            } else {

                tile.appendChild(
                    link
                );
            }


            return true;
        }


        /*
         * COSTCO
         */

        if (
            SITE === "costco"
        ) {

            const productLink =
                tile.querySelector(
                    'a[href*=".product."]'
                );


            if (
                productLink &&
                productLink.parentNode
            ) {

                productLink.parentNode.insertBefore(
                    link,
                    productLink.nextSibling
                );

            } else {

                tile.appendChild(
                    link
                );
            }


            link.style.position =
                "relative";

            link.style.zIndex =
                "1000";

            link.style.pointerEvents =
                "auto";


            return true;
        }


        /*
         * LOWE'S
         */

        if (
            SITE === "lowes"
        ) {

            const title =
                tile.querySelector(
                    '[data-selector="splp-prd-ttl"]'
                );


            if (title) {

                title.insertAdjacentElement(
                    "afterend",
                    link
                );

            } else {

                tile.appendChild(
                    link
                );
            }


            return true;
        }


        /*
         * DEFAULT
         */

        tile.appendChild(
            link
        );


        return true;
    }


    /*
     * -----------------------------------------
     * PROCESS TILE
     * -----------------------------------------
     */

    async function processTile(
        tile,
        url
    ) {

        console.log(
            "PROCESS START:",
            url,
            "TILE:",
            !!tile
        );


        const upc =
            await fetchUPC(
                url
            );


        console.log(
            "PROCESS RESULT:",
            url,
            "UPC:",
            upc
        );


        if (!upc)
            return false;


        /*
         * BEST BUY
         *
         * NEVER use the original tile.
         * Best Buy can rerender it while the
         * product page is being fetched.
         */

        if (
            SITE === "bestbuy"
        ) {

            for (
                let attempt = 0;
                attempt < 8;
                attempt++
            ) {

                const currentTile =
                    findBestBuyTile(
                        url
                    );


                if (
                    currentTile
                ) {

                    return addAmazonLink(
                        currentTile,
                        upc
                    );
                }


                await new Promise(
                    resolve =>
                        setTimeout(
                            resolve,
                            400
                        )
                );
            }


            console.log(
                "BEST BUY TILE NOT FOUND:",
                url
            );


            return false;
        }


        /*
         * WALMART
         *
         * Walmart virtualizes/recycles tiles.
         */

        if (
            SITE === "walmart"
        ) {

            for (
                let attempt = 0;
                attempt < 15;
                attempt++
            ) {

                const currentTile =
                    findWalmartTile(
                        url
                    );


                console.log(
                    "WALMART FIND TILE:",
                    attempt + 1,
                    url,
                    !!currentTile
                );


                if (
                    currentTile
                ) {

                    return addAmazonLink(
                        currentTile,
                        upc
                    );
                }


                await new Promise(
                    resolve =>
                        setTimeout(
                            resolve,
                            250
                        )
                );
            }


            console.log(
                "WALMART TILE NOT FOUND:",
                url
            );


            return false;
        }


        /*
         * OTHER RETAILERS
         */

        if (
            tile
        ) {

            return addAmazonLink(
                tile,
                upc
            );
        }


        console.log(
            "UPC FOUND BUT TILE NOT FOUND:",
            upc,
            url
        );


        return false;
    }


    /*
     * -----------------------------------------
     * PUMP
     * -----------------------------------------
     */

    function pump() {

        while (
            active <
                SCAN_CONCURRENCY &&
            queue.length
        ) {

            const job =
                queue.shift();


            active++;


            Promise.resolve()
                .then(job)
                .catch(
                    error => {

                        console.error(
                            "QUEUE JOB ERROR:",
                            error
                        );
                    }
                )
                .finally(
                    function () {

                        active--;

                        pump();
                    }
                );
        }
    }


    /*
     * -----------------------------------------
     * BEST BUY
     * -----------------------------------------
     *
     * IMPORTANT:
     * A SKU is only considered finished AFTER
     * the UPC has actually been inserted.
     */

    const bestBuyProcessed =
        new Set();


    const bestBuyRetryCount =
        new Map();


    function scanBestBuy() {

        const products =
            getBestBuyURLs();


        let added =
            0;


        for (
            const url
            of products
        ) {

            const match =
                String(url).match(
                    /\/product\/.*\/sku\/(\d+)/i
                );


            if (!match)
                continue;


            const sku =
                match[1];


            if (
                bestBuyProcessed.has(
                    sku
                )
            ) {

                continue;
            }


            /*
             * Don't queue the same SKU repeatedly
             * while it is already waiting.
             */

            if (
                queuedURLs.has(url)
            ) {

                continue;
            }


            queuedURLs.add(url);


            added++;


            queue.push(
                async function () {

                    try {

                        const upc =
                            await fetchUPC(
                                url
                            );


                        if (!upc) {

                            const retries =
                                bestBuyRetryCount.get(
                                    sku
                                ) || 0;


                            bestBuyRetryCount.set(
                                sku,
                                retries + 1
                            );


                            return;
                        }


                        const currentTile =
                            findBestBuyTile(
                                url
                            );


                        if (
                            currentTile
                        ) {

                            const inserted =
                                addAmazonLink(
                                    currentTile,
                                    upc
                                );


                            if (
                                inserted
                            ) {

                                bestBuyProcessed.add(
                                    sku
                                );
                            }

                        } else {

                            console.log(
                                "BEST BUY TILE NOT READY:",
                                sku
                            );
                        }

                    } finally {

                        queuedURLs.delete(
                            url
                        );
                    }
                }
            );
        }


        if (added) {

            pump();
        }
    }


    /*
     * -----------------------------------------
     * NORMAL SCAN
     * -----------------------------------------
     */

    function scan() {

        /*
         * Never scan listings while actually
         * on a product page.
         */

        if (
            isProductURL(
                location.href
            )
        ) {

            return;
        }


        if (
            SITE === "bestbuy"
        ) {

            scanBestBuy();

            return;
        }


        const tiles =
            getTiles();


        console.log(
            "LISTING TILES FOUND:",
            SITE,
            tiles.length
        );


        for (
            const [url, tile]
            of tiles
        ) {

            if (!url)
                continue;


            if (
                queuedURLs.has(
                    url
                )
            ) {

                continue;
            }


            /*
             * If this tile already has a UPC link,
             * don't fetch it again.
             */

            if (
                tile &&
                tile.querySelector(
                    ".retail-upc-mini"
                )
            ) {

                continue;
            }


            queuedURLs.add(
                url
            );


            queue.push(
                async function () {

                    try {

                        await processTile(
                            tile,
                            url
                        );

                    } finally {

                        /*
                         * Delete from queue when finished
                         * so virtualized/re-rendered tiles
                         * can be picked up again.
                         */

                        queuedURLs.delete(
                            url
                        );
                    }
                }
            );
        }


        pump();
    }


    /*
     * -----------------------------------------
     * INITIAL SCAN
     * -----------------------------------------
     */

    setTimeout(
        scan,
        SITE === "bestbuy"
            ? 4000
            : 5000
    );


    /*
     * -----------------------------------------
     * BEST BUY OBSERVER
     * -----------------------------------------
     */

    if (
        SITE === "bestbuy"
    ) {

        let observer =
            null;


        let timer =
            null;


        function scheduleBestBuyScan() {

            clearTimeout(
                timer
            );


            timer =
                setTimeout(
                    function () {

                        scanBestBuy();

                    },
                    2000
                );
        }


        observer =
            new MutationObserver(
                function () {

                    scheduleBestBuyScan();
                }
            );


        if (
            document.body
        ) {

            observer.observe(
                document.body,
                {
                    childList: true,
                    subtree: true
                }
            );
        }
    }


    /*
     * -----------------------------------------
     * OTHER RETAILER OBSERVER
     * -----------------------------------------
     */

    if (
        SITE === "walmart" ||
        SITE === "target" ||
        SITE === "costco" ||
        SITE === "homedepot" ||
        SITE === "lowes"
    ) {

        let observerTimer =
            null;


        let scans =
            0;


        const MAX_SCANS =
            SITE === "walmart"
                ? 30
                : 15;


        const SCAN_DELAY =
            SITE === "walmart"
                ? 1200
                : 2500;


        let lastUrl =
            location.href;


        function checkListingURL() {

            const currentUrl =
                location.href;


            if (
                currentUrl ===
                lastUrl
            ) {

                return false;
            }


            console.log(
                "LISTING URL CHANGED:",
                currentUrl
            );


            lastUrl =
                currentUrl;


            scans =
                0;


            clearTimeout(
                observerTimer
            );


            observerTimer =
                null;


            return true;
        }


        const observer =
            new MutationObserver(
                function () {

                    checkListingURL();


                    /*
                     * Never scan a product page.
                     */

                    if (
                        isProductURL(
                            location.href
                        )
                    ) {

                        return;
                    }


                    if (
                        scans >=
                        MAX_SCANS
                    ) {

                        return;
                    }


                    clearTimeout(
                        observerTimer
                    );


                    observerTimer =
                        setTimeout(
                            function () {

                                if (
                                    isProductURL(
                                        location.href
                                    )
                                ) {

                                    return;
                                }


                                scans++;


                                scan();

                            },
                            SCAN_DELAY
                        );
                }
            );


        if (
            document.body
        ) {

            observer.observe(
                document.body,
                {
                    childList: true,
                    subtree: true
                }
            );
        }


        /*
         * Periodic URL check.
         */

        setInterval(
            function () {

                const changed =
                    checkListingURL();


                if (
                    isProductURL(
                        location.href
                    )
                ) {

                    return;
                }


                if (
                    changed
                ) {

                    scans =
                        0;


                    clearTimeout(
                        observerTimer
                    );


                    observerTimer =
                        setTimeout(
                            function () {

                                if (
                                    isProductURL(
                                        location.href
                                    )
                                ) {

                                    return;
                                }


                                scan();

                            },
                            1000
                        );
                }

            },
            1000
        );
    }


    console.log(
        "RETAIL UPC LISTING SCRIPT READY:",
        SITE
    );

})();