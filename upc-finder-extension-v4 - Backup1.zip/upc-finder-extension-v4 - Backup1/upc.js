// Retail UPC Finder - UPC Extraction
// Supports Walmart, Target, Best Buy, Costco,
// Home Depot, and Lowe's.

(function () {

    console.log(
        "RETAIL UPC MODULE LOADING"
    );


    /*
     * -----------------------------------------
     * DO NOT LOAD TWICE
     * -----------------------------------------
     */

    if (window.RetailUPC) {

        console.log(
            "RETAIL UPC MODULE ALREADY LOADED"
        );

        return;
    }


    const RetailUPC = {};


    /*
     * -----------------------------------------
     * UPC VALIDATION
     * -----------------------------------------
     */

    RetailUPC.isValidUPC = function (code) {

        if (!/^\d{12}$/.test(String(code)))
            return false;


        let sum = 0;


        for (let i = 0; i < 11; i++) {

            const digit =
                String(code).charCodeAt(i) - 48;


            sum +=
                digit *
                (i % 2 === 0 ? 3 : 1);
        }


        const check =
            (10 - (sum % 10)) % 10;


        return (
            check ===
            String(code).charCodeAt(11) - 48
        );
    };


    /*
     * -----------------------------------------
     * NEXT_DATA
     * -----------------------------------------
     */

    RetailUPC.getNextData = function (doc) {

        if (!doc)
            return null;


        const el =
            doc.getElementById(
                "__NEXT_DATA__"
            );


        if (!el)
            return null;


        try {

            return JSON.parse(
                el.textContent
            );

        } catch (e) {

            console.log(
                "NEXT_DATA parse failed:",
                e
            );

            return null;
        }
    };


    /*
     * -----------------------------------------
     * SITE
     * -----------------------------------------
     */

    RetailUPC.getSite = function (host) {

        host =
            String(host || "")
                .toLowerCase();


        if (host.includes("walmart"))
            return "walmart";


        if (host.includes("target"))
            return "target";


        if (host.includes("bestbuy"))
            return "bestbuy";


        if (host.includes("costco"))
            return "costco";


        if (host.includes("homedepot"))
            return "homedepot";


        if (host.includes("lowes"))
            return "lowes";


        return null;
    };


    /*
     * -----------------------------------------
     * BEST BUY
     * -----------------------------------------
     */

    RetailUPC.findBestBuyUPC = function (html) {

        if (!html)
            return null;


        const limit =
            Math.min(
                html.length,
                500000
            );


        const chunk =
            html.substring(
                0,
                limit
            );


        const regex =
            /\b\d{12}\b/g;


        let match;


        while (
            (match = regex.exec(chunk))
        ) {

            const code =
                match[0];


            if (
                RetailUPC.isValidUPC(
                    code
                )
            ) {

                console.log(
                    "BEST BUY UPC:",
                    code
                );

                return code;
            }
        }


        return null;
    };


    /*
     * -----------------------------------------
     * WALMART
     * -----------------------------------------
     */

    RetailUPC.extractWalmart = function (doc) {

        console.log(
            "WALMART EXTRACT START"
        );


        const next =
            RetailUPC.getNextData(
                doc
            );


        if (next) {

            const found =
                findWalmartUPC(
                    next,
                    0
                );

const scriptUPC =
    findWalmartUPCInScripts(
        doc
    );


if (scriptUPC) {

    return scriptUPC;
}

            if (found) {

                console.log(
                    "WALMART UPC FOUND:",
                    found
                );

                return found;
            }
        }


        /*
         * NEXT_DATA text fallback.
         */

        const script =
            doc.getElementById(
                "__NEXT_DATA__"
            );


        if (script) {

            const text =
                script.textContent || "";


            const regex =
                /\b\d{12}\b/g;


            let match;


            while (
                (match =
                    regex.exec(text))
            ) {

                const code =
                    match[0];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "WALMART UPC FALLBACK:",
                        code
                    );

                    return code;
                }
            }
        }


        console.log(
            "NO WALMART UPC"
        );


        return null;
    };


    /*
     * -----------------------------------------
     * WALMART NEXT_DATA SEARCH
     * -----------------------------------------
     */

    function findWalmartUPC(
    obj,
    depth
) {

    depth =
        depth || 0;


    if (
        !obj ||
        typeof obj !== "object" ||
        depth > 20
    ) {

        return null;
    }


    /*
     * First inspect fields whose names
     * contain UPC / GTIN / BARCODE.
     */

    for (
        const key of Object.keys(obj)
    ) {

        const value =
            obj[key];


        if (
            !/(upc|gtin|barcode)/i.test(
                key
            )
        ) {

            continue;
        }


        if (
            typeof value !== "string" &&
            typeof value !== "number"
        ) {

            continue;
        }


        const code =
            String(value)
                .replace(
                    /\D/g,
                    ""
                );


        if (
            code.length === 12 &&
            RetailUPC.isValidUPC(
                code
            )
        ) {

            console.log(
                "WALMART UPC:",
                code,
                "KEY:",
                key
            );


            return code;
        }
    }


    /*
     * Recurse.
     */

    for (
        const key of Object.keys(obj)
    ) {

        const value =
            obj[key];


        if (
            value &&
            typeof value === "object"
        ) {

            const found =
                findWalmartUPC(
                    value,
                    depth + 1
                );


            if (found)
                return found;
        }
    }


    return null;
}


function findWalmartUPCInScripts(doc) {

    const scripts =
        doc.querySelectorAll("script");

    for (
        const script of scripts
    ) {

        const text =
            script.textContent || "";

        if (!text)
            continue;


        /*
         * Skip scripts that have nothing
         * to do with product identifiers.
         */

        if (
            !/(upc|gtin|barcode)/i.test(
                text
            )
        ) {

            continue;
        }


        /*
         * Look only around likely field names.
         */

        const regex =
            /"(?:upc|upcCode|productUpc|productUPC|gtin|gtin12|gtin14|barcode|barcodeValue)"\s*:\s*"?(\d{12,14})"?/gi;


        let match;


        while (
            (match =
                regex.exec(text))
        ) {

            const raw =
                match[1];


            /*
             * UPC-A.
             */

            if (
                raw.length === 12 &&
                RetailUPC.isValidUPC(
                    raw
                )
            ) {

                console.log(
                    "WALMART SCRIPT UPC:",
                    raw
                );

                return raw;
            }
        }
    }


    return null;
}
    /*
     * -----------------------------------------
     * TARGET
     * -----------------------------------------
     */

    RetailUPC.extractTarget = function (
        doc,
        url
    ) {

        console.log(
            "TARGET UPC EXTRACTION START"
        );


        const scripts =
            doc.querySelectorAll(
                "script"
            );


        const regex =
            /\b\d{12}\b/g;


        /*
         * Search scripts.
         */

        for (
            const script of scripts
        ) {

            const text =
                script.textContent;


            if (!text)
                continue;


            regex.lastIndex = 0;


            let match;


            while (
                (match =
                    regex.exec(text))
            ) {

                const code =
                    match[0];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "TARGET UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        /*
         * Body fallback.
         */

        const body =
            doc.body;


        if (!body)
            return null;


        const text =
            body.textContent || "";


        regex.lastIndex = 0;


        let match;


        while (
            (match =
                regex.exec(text))
        ) {

            const code =
                match[0];


            if (
                RetailUPC.isValidUPC(
                    code
                )
            ) {

                console.log(
                    "TARGET UPC FALLBACK:",
                    code
                );


                return code;
            }
        }


        console.log(
            "NO TARGET UPC"
        );


        return null;
    };


    /*
     * -----------------------------------------
     * COSTCO
     * -----------------------------------------
     */

      /*
     * -----------------------------------------
     * COSTCO
     * -----------------------------------------
     */

    RetailUPC.extractCostco = function (doc) {

        console.log(
            "COSTCO UPC EXTRACTION START"
        );


        if (!doc)
            return null;


        /*
         * -----------------------------------------
         * METHOD 1
         * JSON-LD PRODUCT DATA
         * -----------------------------------------
         *
         * Costco commonly exposes product information
         * through JSON-LD. Prefer explicit GTIN/UPC
         * fields rather than grabbing arbitrary numbers.
         */

        const jsonLd =
            doc.querySelectorAll(
                'script[type="application/ld+json"]'
            );


        for (
            const script of jsonLd
        ) {

            const text =
                script.textContent || "";


            if (!text)
                continue;


            try {

                const data =
                    JSON.parse(text);


                const objects =
                    Array.isArray(data)
                        ? data
                        : [data];


                for (
                    const obj of objects
                ) {

                    if (
                        !obj ||
                        typeof obj !== "object"
                    ) {

                        continue;
                    }


                    const candidates = [
                        obj.gtin12,
                        obj.gtin,
                        obj.upc,
                        obj.barcode
                    ];


                    for (
                        const value of candidates
                    ) {

                        if (
                            value === null ||
                            value === undefined
                        ) {

                            continue;
                        }


                        const code =
                            String(value)
                                .replace(
                                    /\D/g,
                                    ""
                                );


                        if (
                            code.length === 12 &&
                            RetailUPC.isValidUPC(
                                code
                            )
                        ) {

                            console.log(
                                "COSTCO JSON-LD UPC:",
                                code
                            );


                            return code;
                        }
                    }
                }

            } catch (e) {

                /*
                 * Some Costco JSON-LD blocks are
                 * malformed or contain multiple
                 * structures. Continue searching.
                 */

            }
        }


        /*
         * -----------------------------------------
         * METHOD 2
         * EXPLICIT UPC / GTIN FIELDS
         * -----------------------------------------
         *
         * Search the raw HTML for fields whose
         * names explicitly identify the number.
         */

        const scripts =
            doc.querySelectorAll(
                "script"
            );


        const fieldRegexes = [

            /["']gtin12["']\s*:\s*["'](\d{12})["']/gi,

            /["']gtin["']\s*:\s*["'](\d{12})["']/gi,

            /["']upc["']\s*:\s*["'](\d{12})["']/gi,

            /["']barcode["']\s*:\s*["'](\d{12})["']/gi,

            /["']UPC["']\s*:\s*["'](\d{12})["']/g,

            /["']UPCCode["']\s*:\s*["'](\d{12})["']/gi,

            /["']upcCode["']\s*:\s*["'](\d{12})["']/gi

        ];


        for (
            const script of scripts
        ) {

            const text =
                script.textContent || "";


            if (!text)
                continue;


            for (
                const regex
                of fieldRegexes
            ) {

                regex.lastIndex = 0;


                let match;


                while (
                    (match =
                        regex.exec(text))
                ) {

                    const code =
                        match[1];


                    if (
                        RetailUPC.isValidUPC(
                            code
                        )
                    ) {

                        console.log(
                            "COSTCO EXPLICIT UPC:",
                            code
                        );


                        return code;
                    }
                }
            }
        }


        /*
         * -----------------------------------------
         * METHOD 3
         * PRODUCT DATA NEAR UPC / GTIN
         * -----------------------------------------
         *
         * Look for an explicit label followed
         * closely by a 12-digit number.
         */

        const combinedText =
            Array.from(
                scripts
            )
                .map(
                    script =>
                        script.textContent || ""
                )
                .join("\n");


        const labeledRegexes = [

            /(?:UPC|UPC\s*Code|UPCCode|GTIN)\s*["']?\s*[:=]\s*["']?(\d{12})/gi,

            /(?:UPC|UPC\s*Code|UPCCode|GTIN)[^0-9]{0,80}(\d{12})/gi

        ];


        for (
            const regex
            of labeledRegexes
        ) {

            regex.lastIndex = 0;


            let match;


            while (
                (match =
                    regex.exec(combinedText))
            ) {

                const code =
                    match[1];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "COSTCO LABELED UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        /*
         * -----------------------------------------
         * METHOD 4
         * VISIBLE PRODUCT PAGE
         * -----------------------------------------
         *
         * Only accept a number when it is close
         * to an explicit UPC/GTIN label.
         */

        const body =
            doc.body;


        if (body) {

            const elements =
                body.querySelectorAll(
                    "div, li, span, p, td"
                );


            for (
                const el of elements
            ) {

                const text =
                    (el.textContent || "")
                        .trim();


                if (
                    !text ||
                    text.length > 250
                ) {

                    continue;
                }


                if (
                    !/(?:UPC|UPC\s*Code|GTIN)/i.test(
                        text
                    )
                ) {

                    continue;
                }


                const matches =
                    text.match(
                        /\b\d{12}\b/g
                    );


                if (!matches)
                    continue;


                for (
                    const code
                    of matches
                ) {

                    if (
                        RetailUPC.isValidUPC(
                            code
                        )
                    ) {

                        console.log(
                            "COSTCO VISIBLE UPC:",
                            code
                        );


                        return code;
                    }
                }
            }
        }


        console.log(
            "NO COSTCO UPC"
        );


        return null;
    };


    /*
     * -----------------------------------------
     * HOME DEPOT
     * -----------------------------------------
     */

    RetailUPC.extractHomeDepot = function (doc) {

        console.log(
            "HOME DEPOT UPC EXTRACTION START"
        );


        const regex =
            /\b\d{12}\b/g;


        const scripts =
            doc.querySelectorAll(
                "script"
            );


        /*
         * Scripts first.
         */

        for (
            const script of scripts
        ) {

            const text =
                script.textContent;


            if (!text)
                continue;


            regex.lastIndex = 0;


            let match;


            while (
                (match =
                    regex.exec(text))
            ) {

                const code =
                    match[0];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "HOME DEPOT UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        /*
         * Body fallback.
         */

        const body =
            doc.body;


        if (!body)
            return null;


        const text =
            body.textContent || "";


        regex.lastIndex = 0;


        let match;


        while (
            (match =
                regex.exec(text))
        ) {

            const code =
                match[0];


            if (
                RetailUPC.isValidUPC(
                    code
                )
            ) {

                console.log(
                    "HOME DEPOT UPC FALLBACK:",
                    code
                );


                return code;
            }
        }


        console.log(
            "NO HOME DEPOT UPC"
        );


        return null;
    };


    /*
     * -----------------------------------------
     * LOWE'S
     * -----------------------------------------
     */

    RetailUPC.extractLowes = function (doc) {

        console.log(
            "LOWES UPC EXTRACTION START"
        );


        const scripts =
            doc.querySelectorAll(
                "script"
            );


        /*
         * METHOD 1:
         * Main barcode.
         */

        const barcodeRegex =
            /"barcode"\s*:\s*"(\d{12})"/g;


        for (
            const script of scripts
        ) {

            const text =
                script.textContent;


            if (!text)
                continue;


            barcodeRegex.lastIndex = 0;


            let match;


            while (
                (match =
                    barcodeRegex.exec(text))
            ) {

                const code =
                    match[1];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "LOWES UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        /*
         * METHOD 2:
         * Consumer-unit EACH barcode.
         */

        const consumerBarcodeRegex =
            /"code"\s*:\s*"(\d{12})"[^}]*?"hierarchyLevel"\s*:\s*"EACH"[^}]*?"consumerUnit"\s*:\s*"true"/g;


        for (
            const script of scripts
        ) {

            const text =
                script.textContent;


            if (!text)
                continue;


            consumerBarcodeRegex.lastIndex = 0;


            let match;


            while (
                (match =
                    consumerBarcodeRegex.exec(text))
            ) {

                const code =
                    match[1];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "LOWES CONSUMER UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        /*
         * METHOD 3:
         * Generic script search.
         */

        const genericRegex =
            /\b\d{12}\b/g;


        for (
            const script of scripts
        ) {

            const text =
                script.textContent;


            if (!text)
                continue;


            genericRegex.lastIndex = 0;


            let match;


            while (
                (match =
                    genericRegex.exec(text))
            ) {

                const code =
                    match[0];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "LOWES GENERIC UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        /*
         * METHOD 4:
         * Body fallback.
         */

        const body =
            doc.body;


        if (body) {

            const text =
                body.textContent || "";


            genericRegex.lastIndex = 0;


            let match;


            while (
                (match =
                    genericRegex.exec(text))
            ) {

                const code =
                    match[0];


                if (
                    RetailUPC.isValidUPC(
                        code
                    )
                ) {

                    console.log(
                        "LOWES BODY UPC:",
                        code
                    );


                    return code;
                }
            }
        }


        console.log(
            "NO LOWES UPC"
        );


        return null;
    };


    /*
     * -----------------------------------------
     * GENERIC EXTRACT
     * -----------------------------------------
     */

    RetailUPC.extract = function (
        site,
        data,
        url
    ) {

        switch (site) {

            case "walmart":

                return RetailUPC.extractWalmart(
                    data
                );


            case "target":

                return RetailUPC.extractTarget(
                    data,
                    url
                );


            case "bestbuy":

                /*
                 * Best Buy normally passes HTML
                 * into findBestBuyUPC().
                 */

                if (typeof data === "string") {

                    return RetailUPC.findBestBuyUPC(
                        data
                    );
                }


                return null;


            case "costco":

                return RetailUPC.extractCostco(
                    data
                );


            case "homedepot":

                return RetailUPC.extractHomeDepot(
                    data
                );


            case "lowes":

                return RetailUPC.extractLowes(
                    data
                );


            default:

                return null;
        }
    };


    /*
     * -----------------------------------------
     * EXPORT
     * -----------------------------------------
     */

    window.RetailUPC =
        RetailUPC;


    console.log(
        "RETAIL UPC MODULE READY:",
        Object.keys(
            window.RetailUPC
        )
    );

})();